<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width,initial-scale=1.0">
        <link rel="stylesheet" href="css/style.css">
        <title>Travels</title>
    </head>
<body>
    <!--header section starts here-->

    <header class="header">

<section class="flex">


    <a href="#home" class="logo">
        <img src="images/logo.jpeg" alt="logo">
    </a>
    <div class="logoname"><p>THE ISLAND.COM</p></div>


    <nav class="navbar">
            <a href="index.php">Home</a>
            <a href="#about">About</a>
            <a href="#packages">Packages</a>
            <a href="#reviews">Reviews</a>
            <a href="book.php">Book</a>
            <a href="admin.php">Login</a>
    </nav>



</section>

</header>

<div class="booking-bg">
    <section class="booking" id="booking">

        <h1 class="heading-title">Book Your Trip!</h1>

        <form action="book_form.php" method="post"  class="book-form"> <!--class="book-form"-->

            
                <div class="inputBox">
                    <span>Name:</span>
                    <input type="text" placeholder="Enter your name" name="name">
                </div>
                <div class="inputBox">
                    <span>Email:</span>
                    <input type="email" placeholder="Enter your email" name="email">
                </div>
                <div class="inputBox">
                    <span>Phone Number:</span>
                    <input type="number" placeholder="Enter your phone number" name="phone">
                </div>
                <div class="inputBox">
                    <span>Address:</span>
                    <input type="text" placeholder="Enter your address" name="address">
                </div>
                <div class="inputBox">
                    <span>Where to:</span>
                    <input type="text" placeholder="Place you want to visit" name="location">
                </div>
                <div class="inputBox">
                    <span>How many:</span>
                    <input type="number" placeholder="number of guests" name="guests">
                </div>
                <div class="inputBox">
                    <span>Arrival date:</span>
                    <input type="date" name="arrivals">
                </div>
                <div class="inputBox">
                    <span>Departure date:</span>
                    <input type="date" name="leaving">
                </div>
                <br>
            </div>
            <input type="submit" value="submit" class="btn" name="send">
        </form>
    </section>
</div>
<!--booking section starts-->
<script src="js/script.js"></script>
    </body></html>
